import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { EmailModule } from './email/email.module';
import { ConfigModule, ConfigService } from '@nestjs/config';
import emailConfig from './core/common/config/emailConfig';
import { validationSchema } from './core/common/config/validationSchema'
import { AuthModule } from './auth/auth.module';
import authConfig from './core/common/config/authConfig';
import { ClientAdminsModule } from './client-admins/client-admins.module';
import * as winston from 'winston';
import {
utilities as nestWinstonModuleUtilities,
WinstonModule,
} from 'nest-winston';
import { CacheModule } from '@nestjs/cache-manager';
// import * as redisStore from 'cache-manager-redis-store';
// import {redisStore} from 'cache-manager-redis-store';
// import * as redisStore from 'cache-manager-ioredis';
import {redisStore} from 'cache-manager-ioredis-yet';
import { RedisClientOptions } from 'redis';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: [`${__dirname}/core/common/config/env/.${process.env.NODE_ENV}.env`],
      load: [emailConfig],
      cache: true,
      validationSchema,
    }),
    // ConfigModule.forFeature(authConfig), // 이게 있어야 Nest가 CONFIGURATION(auth)를 알 수 있음 
    EmailModule, 
    AuthModule,
    ClientAdminsModule,
    WinstonModule.forRoot({
	    transports: [
	      new winston.transports.Console({
	        // level: process.env.NODE_ENV === 'production' ? 'info' : 'silly',
	        level: 'silly',
	        format: winston.format.combine(
	          winston.format.timestamp(),
	          nestWinstonModuleUtilities.format.nestLike('MyAppUserService', { prettyPrint: true }),
	        ),
	      })
	    ]
	  }),
    CacheModule.registerAsync({
      isGlobal: true,
      imports: [ConfigModule], 
      inject: [ConfigService], 
      useFactory: async (configService: ConfigService) => ({
        store: 
        // redisStore,
        await redisStore({ 
            // host: configService.get('REDIS_HOST') || '127.0.0.1',
            host: 'localhost',
            port: parseInt(configService.get('REDIS_PORT'), 10) || 6379,
        }),
        // host: configService.get<string>('REDIS_HOST') || '127.0.0.1',
        host: 'localhost',
        port: parseInt(configService.get<string>('REDIS_PORT'), 10) || 6379,
        ttl: parseInt(configService.get<string>('CACHE_TTL'), 10) || 3600,
        // inject: [ConfigService],        
        db: 0,
      }),
    }),
  ],
  controllers: [AppController],
  providers: [AppService, CacheModule],
})
export class AppModule {}
