export class CreateClientDto {
    name: string;
}