import { CreateClientDto } from "./create-client.dto";

export class CreateClientDbDto extends CreateClientDto {
    isPaid: boolean
}