export class UpdateClientDto {
    name?: string;
  }