export interface UserInfo {
    id: string;
    name: string;
    email: string;
    clientId: string;
    isTwoFactorEnabled: boolean;
}