export class UserLoginValid {
    constructor () {}

    
}