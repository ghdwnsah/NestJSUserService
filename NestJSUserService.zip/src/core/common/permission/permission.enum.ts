export enum Permission {
    CreateUser = 'CreateUser',
    DeleteUser = 'DeleteUser',
    ViewAnalytics = 'ViewAnalytics',
    ManageBilling = 'ManageBilling',
  }