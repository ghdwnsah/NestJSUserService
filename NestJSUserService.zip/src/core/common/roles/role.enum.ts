export enum Role {
  SuperAdmin = 'SuperAdmin',
  ClientAdmin = 'ClientAdmin',
  ClientUser = 'ClientUser',
}