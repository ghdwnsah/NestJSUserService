import { BadRequestException } from '@nestjs/common';

export async function checkEmailExists(
  email: string,
  findUserByEmail: (email: string) => Promise<any>,
) {
  console.log('checkEmailExists()');
  const existingUser = await findUserByEmail(email);
  if (existingUser) {
    throw new BadRequestException('이미 사용 중인 이메일입니다.');
  }
}