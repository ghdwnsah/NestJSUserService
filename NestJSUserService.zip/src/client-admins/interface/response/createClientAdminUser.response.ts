export class CreateClientAdminUserResponse {
  id: string;
  clientCode: string;
}