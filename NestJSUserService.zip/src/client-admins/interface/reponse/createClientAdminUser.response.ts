export class CreateClientAdminUserResponse {
  clientCode: string;
}