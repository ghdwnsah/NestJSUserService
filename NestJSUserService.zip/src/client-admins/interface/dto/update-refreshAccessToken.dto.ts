export class RefreshAccessTokenDto {
    readonly id: string
    readonly refreshToken: string
}