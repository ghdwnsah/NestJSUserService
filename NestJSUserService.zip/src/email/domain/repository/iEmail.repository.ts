export interface IEmailRepository {

}