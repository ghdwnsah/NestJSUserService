export class Login2faResponse {
  accessToken: string;
  refreshToken: string;
  deviceToken: string;
}