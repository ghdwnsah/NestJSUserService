export class VerifyEmailDto {
    signupVerifyToken: string;
}