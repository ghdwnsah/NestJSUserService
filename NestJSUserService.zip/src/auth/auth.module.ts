import { Module } from '@nestjs/common';
import { AuthService } from './auth.service';
import authConfig from 'src/config/authConfig';
import { ConfigModule } from '@nestjs/config';
import { AuthGuard } from './auth.guard';

@Module({
    imports: [ConfigModule.forFeature(authConfig)],
    providers: [AuthService, AuthGuard],
    exports: [AuthService],
})
export class AuthModule {
}
