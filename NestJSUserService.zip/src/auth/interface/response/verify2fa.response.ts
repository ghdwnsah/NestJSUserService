export class verify2faResponse {
    deviceToken: string;
}