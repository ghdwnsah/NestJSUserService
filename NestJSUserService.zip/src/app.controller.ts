import { Controller } from '@nestjs/common';

@Controller({ host: ':version.api.localhost' })
export class AppController {}
