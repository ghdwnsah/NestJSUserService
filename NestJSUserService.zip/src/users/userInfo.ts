export interface UserInfo {
    id: string;
    name: string;
    email: string;
}