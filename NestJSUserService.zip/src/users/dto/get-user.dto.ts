export class GetUsersDto {
    offset: number;
    limit: number;
}