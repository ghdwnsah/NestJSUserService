export class UpdateUserDto {
    name?: string;
    email?: string;
    role?: string;
}