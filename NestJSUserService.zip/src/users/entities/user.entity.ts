export class UserEntity {}
