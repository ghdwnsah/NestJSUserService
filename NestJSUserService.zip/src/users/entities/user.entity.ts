
export class UserEntity {}
