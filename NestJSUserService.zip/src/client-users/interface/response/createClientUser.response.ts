export class CreateClientUserResponse {
    id: string;
}