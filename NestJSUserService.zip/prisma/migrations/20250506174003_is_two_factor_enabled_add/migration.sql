-- AlterTable
ALTER TABLE `User` ADD COLUMN `isTwoFactorEnabled` BOOLEAN NOT NULL DEFAULT false;
