-- AlterTable
ALTER TABLE `Client` ADD COLUMN `isPaid` BOOLEAN NOT NULL DEFAULT false;
