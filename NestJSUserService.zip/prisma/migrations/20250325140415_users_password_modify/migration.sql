-- AlterTable
ALTER TABLE `User` MODIFY `password` VARCHAR(60) NOT NULL;
