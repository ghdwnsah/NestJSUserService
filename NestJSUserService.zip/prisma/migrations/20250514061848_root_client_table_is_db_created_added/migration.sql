-- AlterTable
ALTER TABLE `Client` ADD COLUMN `isDbCreated` BOOLEAN NOT NULL DEFAULT false;
