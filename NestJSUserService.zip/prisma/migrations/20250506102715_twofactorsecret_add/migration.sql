-- AlterTable
ALTER TABLE `User` ADD COLUMN `twoFactorSecret` VARCHAR(191) NULL;
